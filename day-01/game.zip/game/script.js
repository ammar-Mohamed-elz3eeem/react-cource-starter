const addBoxBtn = document.querySelector("#adder");
const removeBoxBtn = document.getElementById("remover");
const boxContainer = document.getElementsByClassName("container")[0];
const boxes = [];

addBoxBtn.addEventListener("click", () => {
	const box = document.createElement("div");
	const incrementBtn = document.createElement("button");
	const decrementBtn = document.createElement("button");
	const btnContainer = document.createElement("div");
	incrementBtn.textContent = "Increase";
	decrementBtn.textContent = "Decrease";
	btnContainer.append(incrementBtn, decrementBtn);
	box.textContent = "0";
	box.append(btnContainer);
	box.classList.add("medht");
	boxes.push(box);
	boxContainer.appendChild(box);
});

removeBoxBtn.addEventListener("click", () => {
	const len = boxes.length;
	console.log(len);
	boxes[len - 1].remove();
	boxes.pop();
});
