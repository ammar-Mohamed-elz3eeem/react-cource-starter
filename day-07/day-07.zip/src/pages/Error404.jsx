import React from "react";

function Error404() {
	return (
		<div className="center">
			<h1>Page not found</h1>
			<h1>404 Error</h1>
		</div>
	);
}

export default Error404;
