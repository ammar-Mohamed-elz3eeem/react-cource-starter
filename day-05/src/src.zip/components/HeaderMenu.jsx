import React, { useState } from "react";
import { loggedInMenu, nonLoggedInMenu } from "../utils/menu";

function HeaderMenu(props) {
	const [loggedIn, setLoggedIn] = useState(false);
}

export default HeaderMenu;
