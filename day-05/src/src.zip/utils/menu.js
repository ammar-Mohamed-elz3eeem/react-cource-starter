export const nonLoggedInMenu = [
	{ name: "Home" },
	{ name: "Login", action: true },
	{ name: "Sign Up" },
];

export const loggedInMenu = [
	{ name: "Home" },
	{ name: "Profile" },
	{ name: "Todos" },
	{ name: "Logout", action: true },
];
